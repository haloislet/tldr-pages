# pkgadd

> Add a package to a CRUX system.

- Install a local software package:

`pkgadd {{package_name}}`

- Update an already installed package from a local package:

`pkgadd -u {{package_name}}`
