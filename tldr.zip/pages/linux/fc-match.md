# fc-match

> Match available fonts.

- Return a sorted list of best matching fonts:

`fc-match -s '{{DejaVu Serif}}'`
