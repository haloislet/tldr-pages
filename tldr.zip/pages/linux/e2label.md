# e2label

> Change the label on an ext2/ext3/ext4 filesystem.

- Change the volume label on a specific ext partition:

`e2label {{/dev/sda1}} "{{label_name}}"`
