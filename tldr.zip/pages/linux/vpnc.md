# vpnc

> A VPN client for the Cisco 3000 VPN Concentrator.

- Connect with a defined configuration file:

`sudo vpnc {{config_file}}`

- Terminate the previously created connection:

`sudo vpnc-disconnect`
