# rtorrent

> Download torrents over the command line.

- Add a torrent file or magnet to be downloaded:

`rtorrent {{torrent_or_magnet}}`

- Start the download:

`<Ctrl>S`

- View details about downloading torrent:

`->`

- Close rtorrent safely:

`<Ctrl>Q`
