# poweroff

> Shutdown the system.

- Poweroff the system:

`sudo poweroff`
