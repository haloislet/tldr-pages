# vipw

> Edit the password file.
> More information: <https://linux.die.net/man/8/vipw>.

- Edit the password file:

`vipw`

- Display the current verson of `vipw`:

`vipw --version`
